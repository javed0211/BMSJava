package tests;

import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class TicketBooking {
	
	public static void main(String[] args) throws MalformedURLException {
		
		//Set the Desired Capabilities
		DesiredCapabilities caps = new DesiredCapabilities();
		caps.setCapability("deviceName", "Pixel 2 API 27");
		caps.setCapability("udid", "emulator-5554"); //Give Device ID of your mobile phone
		caps.setCapability("platformName", "Android");
		caps.setCapability("platformVersion", "8.1");
		caps.setCapability("app", "C:\\Users\\JK-WIN\\Downloads\\BookMyShow-universal-release.apk");
		caps.setCapability("appPackage", "com.bt.bms");
		caps.setCapability("appActivity", "com.movie.bms.splash.views.activities.SplashScreenActivity");
		caps.setCapability("noReset", "true");
		
		//Instantiate Appium Driver
		AppiumDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), caps);

		String packageName = "com.bt.bms:id/";
		
		/*driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		WebElement btnGetStart = driver.findElementById("com.bt.bms:id/language_text_view_label");
		btnGetStart.click();
		
		WebElement btnSkip = driver.findElementById(packageName+"launcher_tv_for_skip");
		btnSkip.click();*/
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		List<AndroidElement> lblTab = driver.findElementsById(packageName+"tab_title_tv_v3");
		for(WebElement we:lblTab)
		{
			if(we.getText().contains("Movies"))
			{
				we.click();
				break;
			}
		}
		
		List<AndroidElement> lblMovies = driver.findElementsById(packageName + "nowshowing_card_view_text_movie_name");
		for(AndroidElement movies:lblMovies)
		{
			if(movies.getText().contains("Zero"))
			{
				movies.click();
				break;
			}
		}
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		AndroidElement btnBookTickets = driver.findElementById(packageName+"movie_details_activity_lin_bookticket");
		btnBookTickets.click();
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		AndroidElement lblDate = driver.findElement(By.id("root_container"));
		lblDate.click();
		
		List<AndroidElement> lnkShowTime = driver.findElementsByClassName("android.widget.TextView");
		for(AndroidElement showTime :lnkShowTime)
		{
			if(showTime.getText().contains("12:10 PM"))
			{
				showTime.click();
				break;
			}
		}
		AndroidElement btnOK = driver.findElement(By.xpath("//*[@class = 'android.view.ViewGroup'and @index='2']/*[@class='android.widget.TextView']"));
		btnOK.click();
		
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		AndroidElement lblNoTickets = driver.findElement(By.xpath("//*[@class = 'android.view.ViewGroup'and @index='6']/*[@class='android.widget.TextView']"));
		lblNoTickets.click();
		
		//WebElement lblGold = driver.findElement(By.xpath("//*[@class = 'android.view.ViewGroup'and @index='1']/*[@class = 'android.view.ViewGroup']/*[@class='android.widget.TextView']"));;
		//lblGold.click();
		
		AndroidElement btnSelectSeat = driver.findElement(By.xpath("//*[@class = 'android.view.ViewGroup'and @index='16']"));
		btnSelectSeat.click();
		
		
		AndroidElement lnkSeat = driver.findElement(By.xpath("//*[class='android.view.View' and @index='2']"));
		lnkSeat.click();
		
		
	}

}